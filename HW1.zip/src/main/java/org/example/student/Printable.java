package org.example.student;

public interface Printable {
    public void print();
}
