package org.example.clock;

public interface Readable {
    public void readTime();
}
