package org.example.task1;

public interface Printable {
    public void print();
}
