package org.example.car;

public interface Drivable {
    public void start();
    public void stop();
    public void drive();
    public void print();
}
