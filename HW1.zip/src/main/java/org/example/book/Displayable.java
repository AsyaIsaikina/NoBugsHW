package org.example.book;

public interface Displayable {
    public void display();
}
